PHIMHAY VIP iOS WebView
Ứng dụng mở website https://phimhayvip.io.vn trong WKWebView, không dựng lại giao diện.
Bundle ID: vn.io.phimhayvip.app | iOS tối thiểu: 15

Build trên iPhone:
1. Giải nén ZIP, tải toàn bộ nội dung lên repository GitHub mới.
2. Vào Actions > Build unsigned IPA > Run workflow.
3. Khi chạy xong, tải artifact PHIMHAYVIP-unsigned-IPA.
4. Đây là IPA CHƯA KÝ. Cần ký bằng chứng chỉ hợp lệ qua ESign/dịch vụ ký trước khi cài lên iPhone.

Lưu ý: App tải website trực tiếp nên cập nhật giao diện trên web sẽ tự hiển thị trong app. Video/cổng thanh toán phải hỗ trợ WKWebView. Gói này chưa phải IPA đã ký và chưa thể cài trực tiếp.
