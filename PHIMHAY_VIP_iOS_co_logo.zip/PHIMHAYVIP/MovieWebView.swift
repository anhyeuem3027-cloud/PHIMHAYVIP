import SwiftUI
import WebKit
struct MovieWebView: UIViewRepresentable {
 func makeCoordinator() -> Coordinator { Coordinator() }
 func makeUIView(context: Context) -> WKWebView {
  let c=WKWebViewConfiguration()
  c.allowsInlineMediaPlayback=true
  c.mediaTypesRequiringUserActionForPlayback=[]
  c.preferences.javaScriptCanOpenWindowsAutomatically=true
  let w=WKWebView(frame:.zero,configuration:c)
  w.navigationDelegate=context.coordinator
  w.uiDelegate=context.coordinator
  w.allowsBackForwardNavigationGestures=true
  w.scrollView.contentInsetAdjustmentBehavior = .never
  w.load(URLRequest(url:URL(string:"https://phimhayvip.io.vn")!))
  context.coordinator.webView=w
  return w
 }
 func updateUIView(_ uiView:WKWebView,context:Context){}
 final class Coordinator:NSObject,WKNavigationDelegate,WKUIDelegate {
  weak var webView:WKWebView?
  func webView(_ webView:WKWebView,decidePolicyFor action:WKNavigationAction,decisionHandler:@escaping(WKNavigationActionPolicy)->Void){
   guard let url=action.request.url else { decisionHandler(.cancel); return }
   if action.targetFrame == nil { webView.load(URLRequest(url:url)); decisionHandler(.cancel); return }
   if ["http","https"].contains(url.scheme?.lowercased() ?? "") { decisionHandler(.allow) }
   else { UIApplication.shared.open(url); decisionHandler(.cancel) }
  }
  func webView(_ webView:WKWebView,createWebViewWith configuration:WKWebViewConfiguration,for action:WKNavigationAction,windowFeatures:WKWindowFeatures)->WKWebView? {
   if action.targetFrame == nil,let url=action.request.url { webView.load(URLRequest(url:url)) }
   return nil
  }
 }
}
